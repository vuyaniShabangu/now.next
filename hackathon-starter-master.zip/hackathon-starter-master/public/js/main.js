$(document).ready(function() {

  // Place JavaScript code here...

});