# now.next()
Final Year Capstone Project; COS301

VM Shabangu - 11171139 

S Masemola - 12270467 

B Nxumalo - 12201911 

A Malan - 12265731 

MS Thosago - 13062060


[![Stories in Ready](https://badge.waffle.io/vuyaniShabangu/now.next.svg?label=ready&title=Ready)](http://waffle.io/vuyaniShabangu/now.next)

[![Stories in Testing](https://badge.waffle.io/vuyaniShabangu/now.next.svg?label=testing&title=Testing)](http://waffle.io/vuyaniShabangu/now.next)
